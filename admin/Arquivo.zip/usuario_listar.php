<?php include"scripts/restrito_admin.php"; ?>
<?php include"header.php"; ?>
<div id="box"><!-- INICIO DIV BOX -->
  
  <div id="header"><!-- INICIO DIV HEADER -->
  
    <div id="header_logo"><!-- INICIO DIV HEADER_LOGO -->
    <a href="painel.php"><img src="imgs/logo.png" alt="" border="0" /></a>
    </div><!-- FIM DIV HEADER_LOGO -->
    
    <div id="header_publicidade"><!-- INICIO DIV HEADER_PUBLICIDADE -->
    </div><!-- FIM DIV HEADER_PUBLICIDADE -->
  
  </div><!-- FIM DIV HEADER -->
  
  <div id="content"><!-- INICIO DIV CONTENT -->
  
    <div id="menu"><!-- INICIO DIV MENU -->
	<?php include "menu.php"; ?>
    </div><!-- FIM DIV MENU -->
    
    <div id="conteudo"><!-- INICIO DIV CONTEUDO -->
		<div class="titulo">Usuários | Listar/Editar/Excluir</div>
	
<?php if(isset($_GET['delid'])){
	
	$id_user = $_GET['delid'];
	
	$verifica_usuario = mysql_query("SELECT nivel FROM users WHERE id = '$id_user'")
	                  or die(mysql_error());
					  
	 if(@mysql_num_rows($verifica_usuario) <= '0') echo 'Erro ao selecionar o usuario!';
	 else{
		 
		while($res_usuario=mysql_fetch_array($verifica_usuario)){
			 
			$nivel = $res_usuario[0];
			
		}
	 }
	if($nivel == 'admin'){
		echo "<div class=\"ms no\">O Usuário Admin não pode ser excluido!</div>";
	}else{
	
	$deletar_usuario = mysql_query("DELETE FROM users WHERE id = '$id_user'")
	                   or die(mysql_error());
					   
	if($deletar_usuario >= '1'){
		echo "<div class=\"ms ok\">Usuário foi excluido com succeso!</div>";
	}else{
		echo "<div class=\"ms ok\">Erro ao excluir o usuário!</div>";
	}
  }
}
?> 
    <?php    
		$SelecionaUsuarios = mysql_query("SELECT * FROM users ORDER BY nivel ASC") or die(mysql_error());
					  
		if(@mysql_num_rows($SelecionaUsuarios) <= '0') echo "<div class=\"ms no\">Nenhum Usuário cadastrado!</div>";
			else{
	?>
    <center>
    <table width="710" border="0" align="center" cellpadding="0" cellspacing="0" class="tbusuarios">
    <tr class="ses">
      <td width="30" align="center" height="30">&nbsp;</td>
        <td width="442" align="center">NOME</td>
        <td width="50" align="center">NIVEL</td>
        <td align="center" colspan="2">AÇÕES</td>
    </tr>
	<?php
	 while($ResSelecionaUsuarios=mysql_fetch_array($SelecionaUsuarios)){
		 
		 $PegaID      = $ResSelecionaUsuarios['id'];
		 $PegaNome    = $ResSelecionaUsuarios['nome'];
		 $PegaEmail   = $ResSelecionaUsuarios['email'];
		 $PegaNivel   = $ResSelecionaUsuarios['nivel'];
		 $default = "http://www.gravatar.com/avatar/ad516503a11cd5ca435acc9bb6523536%3Fs%3D40&size=40";
		 $size = 40;
		 $grav_url = "http://www.gravatar.com/avatar.php?gravatar_id=" . md5( strtolower( $PegaEmail ) ) . "&default=" . urlencode( $default ) . "&size=" . $size;
			 
	?>
    <tr>
        <td align="center" valign="middle">
        <img style="padding:3px; background:#FFF; border:1px solid #CCC;" src="<?php echo $grav_url; ?>" title="<?php echo $PegaNome; ?>" width="40">
        </td>
        <td align="center">
			<?php echo $PegaNome; ?>
        </td>
        <td align="center" style="color:#900; font-weight:bold;">
			<?php echo strtoupper ($PegaNivel); ?>
        </td>
        <td width="30" align="center">
            <a href="usuario_editar.php?id=<?php echo $PegaID; ?>" title="Editar">
                <img src="imgs/edit.png" alt="Editar" title="Editar" />
            </a>
        </td>
        <td width="30" align="center">
            <a href="usuario_listar.php?delid=<?php echo $PegaID; ?>" title="Excluir">
                <img src="imgs/no.png" alt="Excluir" title="Excluir" />
            </a>
        </td>
    </tr>
    <?php 
		}
	}
	?>
    </table>
    </center>

    </div><!-- FIM DIV CONTEUDO -->
  
</div><!-- FIM DIV CONTENT -->
  
<div id="clear"></div><!-- INICIO E FIM DIV CLEAR -->

</div><!-- FIM DIV BOX -->
<?php include"footer.php"; ?>