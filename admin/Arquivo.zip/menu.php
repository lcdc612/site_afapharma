 <?php
	 $email = $_SESSION['MM_Username'];
	 $boas_vindas = mysql_query("SELECT nivel FROM users WHERE email = '$email'")
	                  or die(mysql_error());
	 if(@mysql_num_rows($boas_vindas) <= '0') echo 'Erro ao selecionar o e-mail!';
	 else{
		 
		 while($res_boas_vindas=mysql_fetch_array($boas_vindas)){
			 
			 $nivel = $res_boas_vindas[0];
		 }
	 }
?>
<?php if($nivel == 'admin'){
?>
<h1><a href="#">Gerenciar Site</a></h1>
    <ul>
    	<li><a href="painel.php">Home</a></li>
        <li><a href="configs_global.php">Configurações</a></li>
    </ul>
<h1><a href="#">Gerenciar Notícias</a></h1>
    <ul>
        <li><a href="noticias_cadastro.php">Cadastrar</a></li>
        <li><a href="noticias_visualizar.php">Listar/Editar/Excluir</a></li>   
    </ul>    
<h1><a href="#">Gerenciar Usuário</a></h1>
    <ul>
        <li><a href="usuario_cadastro.php">Cadastrar</a></li>
        <li><a href="usuario_listar.php">Listar Usuários</a></li>
        <li><a href="usuario_perfil.php">Editar Perfil</a></li>
    </ul>
<h1><a href="#">Funções</a></h1>
    <ul>
        <li><a href="http://www.afaparhma.com" title="AFA Pharma" target="_blank">Visualizar o Site</a></li>
        <li><a href="logof.php">Deslogar do painel</a></li>
    </ul>
<?php }else{
?>
<h1><a href="#">Gerenciar Site</a></h1>
    <ul>
    	<li><a href="painel.php">Home</a></li>
        <li><a href="configs_global.php">Configurações</a></li>
    </ul>
<h1><a href="#">Gerenciar Notícias</a></h1>
    <ul>
        <li><a href="noticias_cadastro.php">Cadastrar</a></li>
        <li><a href="noticias_visualizar.php">Listar/Editar/Excluir</a></li>   
    </ul>    
<h1><a href="#">Gerenciar Usuário</a></h1>
    <ul>
        <li><a href="usuario_cadastro.php">Cadastrar</a></li>
        <li><a href="usuario_listar.php">Listar Usuários</a></li>
        <li><a href="usuario_perfil.php">Editar Perfil</a></li>
    </ul>
<h1><a href="#">Funções</a></h1>
    <ul>
        <li><a href="http://www.afaparhma.com" title="AFA Pharma" target="_blank">Visualizar o Site</a></li>
        <li><a href="logof.php">Deslogar do painel</a></li>
    </ul>
<?php 
}
?>